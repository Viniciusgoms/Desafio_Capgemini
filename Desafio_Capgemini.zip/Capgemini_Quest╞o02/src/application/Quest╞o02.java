package application;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Quest�o02 {

public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
	
    	System.out.println("Quantos n�meros o vetor possui?");
    	int n = sc.nextInt();
    	
    	Integer[] vect = new Integer[n];
    	
    	System.out.println("Adicione "+n+" n�meros inteiros a este vetor:");
    	for(int i=0; i<n; i++) {
    		vect[i] = sc.nextInt();
    	}
    	
    	Arrays.sort(vect, Collections.reverseOrder());
    	
        System.out.println("Determine um n�mero inteiro para encontrar a diferen�a entre os pares:");
        Integer x = sc.nextInt();
        int contador = 0;
        String pares ="";
    	for(int i = 0; i<n; i++){
    	    for(int y = i+1; y<n; y++){
    	        if((vect[i] - vect[y]) == x){
    	            contador++;
    	           System.out.print("[" + vect[i] + "," + vect[y] + "] "); 
    	        }
    	    }
    	}
    	System.out.println();
    	System.out.println("Resultado: " + contador + " pares.");
    	
    	sc.close();
	}	
}