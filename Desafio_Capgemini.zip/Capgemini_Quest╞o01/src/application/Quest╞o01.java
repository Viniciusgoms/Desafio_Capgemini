package application;

import java.util.Arrays;
import java.util.Scanner;

public class Quest�o01 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Digite um n�mero impar: ");
		int n = sc.nextInt();

		int[] vect = new int[n];

		System.out.println("Digite " + n + " n�meros inteiros:");

		for (int i = 0; i < n; i++) {
			vect[i] = sc.nextInt();
		}

		Arrays.sort(vect);

		int y = (int) Math.floor(n / 2);

		System.out.println("Mediana = " + vect[y]);

		
		sc.close();
	}

}