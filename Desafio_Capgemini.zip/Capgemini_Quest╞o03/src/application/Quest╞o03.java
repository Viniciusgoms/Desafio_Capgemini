package application;

import java.util.Scanner;

public class Quest�o03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Escreva uma frase:");
		String x = sc.nextLine();
		
		x=x.replaceAll(" ","");
		int tamanho = x.length();
		int raiz = (int) Math.ceil(Math.sqrt(tamanho));
		
        for(int i = 0; i < raiz ; i++){
            int posicao = i;
            for(int y = 0; y < raiz ; y++){
                if (posicao < tamanho && (i + raiz) < tamanho){
                    System.out.print(x.charAt(posicao));
                    posicao = posicao + raiz;
                } 
            }
            System.out.print(" ");
        }	
        sc.close();
	}
}